#Celcius to Fareinheit conversion
def celcius_to_fareinheit(a):
    return (a*1.8)+32

#Fareinheit to Celcius conversion
def fareinheit_to_celcius(b):
    return ((b-32)*5)/9

#Celcius to Kelvin conversion
def celcius_to_kelvin(c):
    return c+273.15

#Kelvin to Celcius conversion
def kelvin_to_celcius(d):
    return d-273.15

#Fareinheit to Kelvin conversion
def fareinheit_to_kelvin(e):
    return ((e-32)*0.56)+273.15

#Kelvin to Fareinheit conversion
def kelvin_to_fareinheit(f):
    return ((f-273.15)*1.8)+32


